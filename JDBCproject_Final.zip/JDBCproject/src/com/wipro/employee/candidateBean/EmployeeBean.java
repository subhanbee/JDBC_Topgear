package com.wipro.employee.candidateBean;

import java.math.BigDecimal;
import java.util.ArrayList;

import com.wipro.employee.bean.Employee;
import com.wipro.employee.dao.EmployeeDAO;
import com.wipro.employee.exception.WrongDataException;

public class EmployeeBean {
	
	
	public String addEmployee(Employee emp)throws Exception {
		
		String status="";
		try {
		if(String.valueOf(emp.getEcode()).length()<4||emp.getEname().length()>20||
				(!emp.getDesignation().equalsIgnoreCase("SE")&&!emp.getDesignation().equalsIgnoreCase("SSE")&&!emp.getDesignation().equalsIgnoreCase("SS")&&!emp.getDesignation().equalsIgnoreCase("SSS"))
				||(emp.getAge()<18||emp.getAge()>80)||emp.getBasic_pay().floatValue()<6000.00){
			
			throw new WrongDataException();
			}
		}
		catch(Exception e) {
			return "Data Incorrect";}
		EmployeeDAO emDao=new EmployeeDAO();
	   status=emDao.addEmployee(emp);
	   System.out.println(status);
	      return status;
	
	}
	public String modifyRecord(int ecode,String des) {
		EmployeeDAO emDao=new EmployeeDAO();
		String st=emDao.modifyRecord(ecode,des);
		System.out.println(st);
		return st;}
	public String modifyRecordSalary(int ecode,BigDecimal dec) {
		EmployeeDAO emDao=new EmployeeDAO();
		String st=emDao.modifyRecordSalary(ecode,dec);
		System.out.println(st);
		return st;}
	public float salarySlip(int ecode) {
		EmployeeDAO emDao=new EmployeeDAO();
		float salary=emDao.salarySlip(ecode);
		System.out.println(salary);
		System.out.println("Salary Slip is generated");
		return salary;
	}
	
	public void display() throws Exception {
		EmployeeDAO emDao=new EmployeeDAO();
		ArrayList<Employee> al=emDao.display();
		for(Employee e: al) {
			System.out.println(e.toString());
			
		}
	}
		public boolean delete(int ecode) {
			EmployeeDAO emDao=new EmployeeDAO();
			boolean status=emDao.delete(ecode);
			System.out.println("Employee data deleted");
			return status;
			
			
		}
		
	}
	
		
		
		
	
	
	

