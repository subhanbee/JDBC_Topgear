package com.wipro.employee.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import org.apache.log4j.*;
import java.sql.*;
import java.sql.Date;

import com.wipro.employee.bean.Employee;

import com.wipro.employee.util.DAOUtil;
 
public class EmployeeDAO {
	static final Logger debugLog = Logger.getLogger("debugLog");
    static final Logger resultLog = Logger.getLogger("reportsLog");
	public String addEmployee(Employee emp) {
	String status="";
		try{
			Connection conn=DAOUtil.getDBConn();
		PreparedStatement pst=conn.prepareStatement("insert into Emloyee values(?,?,?,?,?)");
		pst.setInt(1,emp.getEcode());
		pst.setString(2, emp.getEname());
		pst.setString(3, emp.getDesignation());
		pst.setInt(4, emp.getAge());
		pst.setBigDecimal(5, emp.getBasic_pay());
		int record=pst.executeUpdate();
		//PropertyConfigurator.configure("log.properties");
		if(record==1) {
			status="Employee details inserted";
			}
		else
		status="Failed to insert the Employee data";}
		catch(Exception e) {
			return "FAIL";}
		
	return status;
	}
	
	public String modifyRecord(int eCode,String des)  {
		String status="";
		try {
		Connection conn=DAOUtil.getDBConn();
		PreparedStatement pst=conn.prepareStatement("update Emloyee set Designation=? where Ecode=?");
		pst.setString(1,des);
		pst.setInt(2,eCode);
		int update=pst.executeUpdate();
		long date_of_modification=System.currentTimeMillis();
		if(update==1)
		{
			debugLog.info("Modification Employee ID: "+eCode);
			debugLog.info("Modidfication Date:"+new Date(date_of_modification));
			debugLog.info("Modification Details are change in Designation and i.e : "+des);
			debugLog.info("========================================================");
			status="Success";
		}
		return status;
		
		
		}
		catch(Exception e)
		{
			return "FAIL";
		}
		}
	   public String modifyRecordSalary(int eCode,BigDecimal dec)  {
		String status="";
		try {
		Connection conn=DAOUtil.getDBConn();
		PreparedStatement pst=conn.prepareStatement("update Emloyee set Basic_ay=? where Ecode=?");
		pst.setBigDecimal(1,dec);
		pst.setInt(2,eCode);
		int update=pst.executeUpdate();
		long date_of_modification=System.currentTimeMillis();
		if(update==1)
		{
			debugLog.info("Modification for Employee and ID is: "+eCode);
			debugLog.info("Modidfication Date: "+new Date(date_of_modification));
			debugLog.info("Modification Details are change in Basic Salary:"+dec);
			debugLog.info("========================================================");
			status="Success";
		}
		return status;}
		catch(Exception e)
		{
			return "FAIL";
		}
		}
	/*
	 * XYZ Limited
	 * 
	 * Date: 08-Jun-2012
	 * 
	 * Employee Code: 5085 Employee Name: Sriram Employee Designation: SS()
	 * 
	 * BASIC: 6000 HRA: 600 DA: 1200 Salary = 7800
	 */

	    public float salarySlip(int ecode) {
		String status="";
		try {
		Connection conn=DAOUtil.getDBConn();
		PreparedStatement pst=conn.prepareStatement("select * from Emloyee where Ecode=?");
		pst.setInt(1, ecode);
		ResultSet rs=pst.executeQuery();
		int id=0;
		String name=null;
		String des=null;
		
		
		BigDecimal basic = null;
		if(rs.next()) {
			 id=rs.getInt(1);
			 name=rs.getString(2);
			 des=rs.getString(3);
			basic=rs.getBigDecimal(5);
			System.out.println(id);
		}
		float sal=basic.floatValue();
		float DA =(float) (0.2*sal);
		float HRA = (float)0.1*sal;
		float salary = sal + DA + HRA;
		resultLog.info("                         "+"         XYZ Limited         "+"                          ");
		resultLog.info("");
		resultLog.info("                                                                         Date: "+new Date(System.currentTimeMillis()));
		resultLog.info("Employee Code: "+id);
		resultLog.info("Employee Name: "+name);
		resultLog.info("Employee Designation: "+des);
		resultLog.info("BASIC: "+basic);
		resultLog.info("HRA: "+HRA);
		resultLog.info("DA: "+DA);
		resultLog.info("Salary= "+salary);
		
		return salary;
		}
		catch(Exception e)
		{
			return 0;
		}
		}
	    public ArrayList<Employee> display() throws Exception{
		String status="";
		ArrayList<Employee> al=new ArrayList<Employee>();
		Connection conn=DAOUtil.getDBConn();
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery("select * from emloyee");
		while(rs.next()) {
			Employee em=new Employee(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getBigDecimal(5));
			al.add(em);
			}
		
		return al;}
	    public boolean delete(int ecode) {
	    	boolean status=false;
			try {
			Connection conn=DAOUtil.getDBConn();
			PreparedStatement pst=conn.prepareStatement("select * from emloyee where ecode=?");
			pst.setInt(1, ecode);
			ResultSet rs=pst.executeQuery();
			Employee em=null;
			while(rs.next()){
			em=new Employee(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getBigDecimal(5));
			}
			float sal=(float)em.getBasic_pay().floatValue();
			float DA =(float) (0.2*sal);
			System.out.println(DA);
			float HRA = (float)0.1*sal;
			float salary = sal + DA + HRA;
			BigDecimal salary1=new BigDecimal(salary);
			long millis=System.currentTimeMillis();  
	        
			PreparedStatement pst1=conn.prepareStatement("insert into emloyeelog values(?,?,?,?,?)");
			pst1.setInt(1,em.getEcode());
			pst1.setString(2, em.getEname());
			pst1.setString(3, em.getDesignation());
			pst1.setBigDecimal(4, salary1);
			pst1.setDate(5,new Date(millis));
			int record=pst1.executeUpdate();
			PreparedStatement pst2=conn.prepareStatement("delete from emloyee where ecode=?");	
			pst2.setInt(1, ecode);
			 status=pst2.execute();
			 return status;
				}
			catch(Exception e) {
				return status;
				}
			}
	    
	    


}
