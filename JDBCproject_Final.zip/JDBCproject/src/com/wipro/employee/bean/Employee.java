package com.wipro.employee.bean;

import java.math.BigDecimal;

public class Employee {
	private int ecode;
	private String ename;
	private String designation;
	private int age;
	private BigDecimal basic_pay;
	public Employee() {
		super();
	}
	public Employee(int ecode, String ename, String designation, int age, BigDecimal basic_pay) {
		super();
		this.ecode = ecode;
		this.ename = ename;
		this.designation = designation;
		this.age = age;
		this.basic_pay = basic_pay;
	}
	public int getEcode() {
		return ecode;
	}
	public void setEcode(int ecode) {
		this.ecode = ecode;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;}
	public BigDecimal getBasic_pay() {
		return basic_pay;
	}
	public void setBasic_pay(BigDecimal basic_pay) {
		this.basic_pay = basic_pay;
	}
	@Override
	public String toString() {
		return "Employee [ecode=" + ecode + ", ename=" + ename + ", designation=" + designation + ", age=" + age
				+ ", basic_pay=" + basic_pay + "]";
	}
	

}
