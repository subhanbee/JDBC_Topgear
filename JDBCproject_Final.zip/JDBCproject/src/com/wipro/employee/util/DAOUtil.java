package com.wipro.employee.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DAOUtil {
	public static Connection getDBConn() throws Exception
	{
		Connection con=null;
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hb_student_tracker","hbstudent","hsbcstudent");
		System.out.println("connection made");
		return con;
	}

}
