import java.math.BigDecimal;
import java.util.Scanner;

import com.wipro.employee.bean.Employee;
import com.wipro.employee.candidateBean.EmployeeBean;
import com.wipro.employee.dao.EmployeeDAO;

public class MainClass {

	public static void main(String[] args) throws Exception {
		Scanner sc=new Scanner(System.in);
		do {
		System.out.println("Choose the option to perform :");
		System.out.println("1.To Add the new emvloyee Details");
		System.out.println("2.To modify the employee Designation ");
		System.out.println("3.To modify the employee Basic pay ");
		System.out.println("4.To display the all Employee details");
		System.out.println("5.To see the Salary pay slip");
		System.out.println("6.TO delete the Employee details");
		System.out.println("7.To exit the program");
		int choice=sc.nextInt();
		Employee e=null;
		EmployeeBean em=new EmployeeBean();
		if(choice==1) {
			System.out.println("please add the Employee details as folloing: ");
			System.out.println("Enter the Ecode of Employee:");
			int ecode=sc.nextInt();
			System.out.println("Enter the Name of the Employee:");
			String eName=sc.next();
			System.out.println("Enter the Designation of Eployee:");
			String desi=sc.next();
			System.out.println("Enter the age of the Employee:");
			int age=sc.nextInt();
			System.out.println("Enter the salary of the Employee:");
			BigDecimal salary=sc.nextBigDecimal();
			e=new Employee(ecode,eName,desi,age,salary);
			em.addEmployee(e);
		System.out.println("Employee data has been insetered into table");
		}
		if(choice==2) {
			System.out.println("please enter the Designation to modify for the Emplyee");
			System.out.println("Enter the Employee Ecode :");
			int ecode=sc.nextInt();
			System.out.println("Enter the designation to modify");
			String des=sc.next();
		em.modifyRecord(ecode,des);
		}
		if(choice==3) {
			System.out.println("please enter the Designation to modify for the Emplyee");
			System.out.println("Enter the Employee Ecode :");
			int ecode=sc.nextInt();
			System.out.println("Enter the Basic pay to modify");
			BigDecimal basic=sc.nextBigDecimal();
		em.modifyRecordSalary(ecode,basic);
			
		}
		if(choice==4) {
		em.display();}
		
		if(choice==5) {
			System.out.println("Enter the employee code:");
			int ecode=sc.nextInt();
		em.salarySlip(ecode);}
		if(choice==6) {
			System.out.println("Enter the Employee Ecode :");
			int ecode=sc.nextInt();
			em.delete(ecode);
		
			System.out.println("Employee details deleted ");
		}
		if(choice==7) {
		break;
		}
		}
		while(true);
		
		
		
	}

}
